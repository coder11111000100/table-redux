export const selectFilterComponent = state => state.filter;
