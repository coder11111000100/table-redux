import { Link } from "react-router-dom";
function Home() {
  return <Link to='/' key={"Home"}></Link>;
}
export { Home };
